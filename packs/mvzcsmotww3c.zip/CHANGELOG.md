# PVP for Cuties v1.6.3
- update to 26.3
_glow trims currently dont work yet sorry_