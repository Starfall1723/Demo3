# Features



<details>
<summary>💅New Armor With Crowns💅</summary>

![All Armortypes side by side](https://cdn.modrinth.com/data/iQx2ijVe/images/d45c216e6bb2d93cee5dcc89269413a909e9ab2d.png)

## Even works with Armor Trims !!

![All Armors Side by Side but with Trims](https://cdn.modrinth.com/data/iQx2ijVe/images/5391305e35c64f7bd8c16b05cc5653d1a7c716d8.png)

</details>


### 
<details>
<summary>🥕Eating Animation!!!🥕[1.21.4+]</summary>

![Foods and Thier Animations](https://cdn.modrinth.com/data/o962rBDR/images/1f7ab4d15103c2c2f758ccf37d72e2d5593ec192.gif)

</details>

<details>
<summary>⚔️Items⚔️</summary>



- [New Diamond and Netherite Tools](https://cdn.modrinth.com/data/iQx2ijVe/images/d9bc5d420c4a3dbb9efa0ba5e8ea4a68f96e5dc0.png)
- Darker Netherite
- New Trident
- White Gap
- Darker Buckets(WiP)
- 2D Beds from [VanillaTweaks](https://vanillatweaks.net/picker/resource-packs/)

</details>






<details>
<summary>👀Unobstrusive👀</summary>

- No Fishing Bobber
- [Lower Shield](https://cdn.modrinth.com/data/iQx2ijVe/images/ba3bfd3e45aeb48e7aea4fc05177f78a2aee88a0.png)
- [Lower Fire](https://cdn.modrinth.com/data/iQx2ijVe/images/ba3bfd3e45aeb48e7aea4fc05177f78a2aee88a0.png)
- [Smaller Totem(for 1.21.4+ the totem is only small when holding it in the offhand)](https://cdn.modrinth.com/data/iQx2ijVe/images/d506b6a37ba2d645fdc55a737228df44a519b37c.png)
- No Vingette
- No Pumpkin Overlay
- Unobstrusive Enchantment Glint from [VanillaTweaks](https://vanillatweaks.net/picker/resource-packs/)
- No Sweep and Crit Particles




</details>


<details>
<summary>🩷Pink Damage Tilt🩷</summary>

![Steve is taking damage](https://cdn.modrinth.com/data/iQx2ijVe/images/77f7580c754dfc9dbe88d1ddb7d86ae7b56eab62.png)

</details>




## Credits

- Myself lol
- [rubl](https://www.planetminecraft.com/member/rubl/) for helping with shader code
- [Vanilla Tweaks](https://vanillatweaks.net/)
- [xSpinHDx](https://modrinth.com/resourcepack/vanilla-plus-jaronwqhd)
- [Ivory](https://www.youtube.com/@MythrodakTV)
- [Bergundy1](https://modrinth.com/user/Bergundy1)
- [PiXeLJoWY32](https://modrinth.com/user/PiXeLJoWY32)
- [frugbug](https://modrinth.com/user/frugbug)

